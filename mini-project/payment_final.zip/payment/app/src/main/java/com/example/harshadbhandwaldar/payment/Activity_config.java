package com.example.harshadbhandwaldar.payment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_config extends AppCompatActivity {
    EditText etdate ;
    Button btnset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        etdate = (EditText) findViewById(R.id.etDate);
        btnset= (Button) findViewById(R.id.btnSet);

        btnset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity_pay.my_date= etdate.getText().toString();
                Toast.makeText(Activity_config.this, "Deadline Updated!", Toast.LENGTH_SHORT).show();
                Intent ij = new Intent(Activity_config.this,MainActivity.class);
                startActivity(ij);
            }
        });

    }
}
