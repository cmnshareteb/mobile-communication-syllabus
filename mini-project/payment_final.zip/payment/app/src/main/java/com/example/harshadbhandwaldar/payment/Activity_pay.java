package com.example.harshadbhandwaldar.payment;

import android.app.Activity;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PayPalService;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PaymentConfirmation;

import org.json.JSONException;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Activity_pay extends AppCompatActivity {
    TextView name3;
    Button btnPay;
    Button btnpay2;
    EditText chalan;
    public static String my_date = "06/09/2019";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        //paypal
        Intent intent = new Intent(this, PayPalService.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, MyGlobal.config);
        startService(intent);

        name3 = (TextView) findViewById(R.id.txtName);
        btnPay = (Button) findViewById(R.id.btn_pay);
        btnpay2 = (Button) findViewById(R.id.btn_pay2);
        chalan = (EditText) findViewById(R.id.etchalanid);


        if(MyGlobal.fee_payed == true)
        {
            Intent p = new Intent(Activity_pay.this, Activity_success.class);
            startActivity(p);
            finish();
        }


        TextView tv = (TextView) findViewById(R.id.txtPay);
        tv.setText(String.valueOf(MyGlobal.id));



        TextView tv1 = (TextView) findViewById(R.id.txtAmt);
        tv1.setText(String.valueOf(MyGlobal.fee));

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date strDate= null;
        try {
            strDate = sdf.parse(my_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (System.currentTimeMillis() > strDate.getTime()) {
            btnPay.setEnabled(false);
            Toast.makeText(this, "Deadline over.", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Deadline not over.", Toast.LENGTH_SHORT).show();
        }

            name3.setText(MyGlobal.name);

        btnpay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String chk = chalan.getText().toString();
                if (chk.equals("")) {
                    Toast.makeText(Activity_pay.this, "Please enter chalan ID.", Toast.LENGTH_SHORT).show();
                } else {
                    MyGlobal.upi = chalan.getText().toString();
                    MyGlobal.fee_payed = true;
                    Intent p = new Intent(Activity_pay.this, Activity_success.class);
                    startActivity(p);
                    finish();
                }
            }
        });

           btnPay.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view)
               {
                   //Creating a paypalpayment
                   PayPalPayment payment = new PayPalPayment(new BigDecimal(String.valueOf(MyGlobal.fee)), "USD", " Fee",
                           PayPalPayment.PAYMENT_INTENT_SALE);

                   //Creating Paypal Payment activity intent
                   Intent intent = new Intent(Activity_pay.this, PaymentActivity.class);

                   //putting the paypal configuration to the intent
                   intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION,MyGlobal.config);

                   //Puting paypal payment to the intent
                   intent.putExtra(PaymentActivity.EXTRA_PAYMENT, payment);

                   //Starting the intent activity for result
                   //the request code will be used on the method onActivityResult
                   startActivityForResult(intent, MyGlobal.PAYPAL_REQUEST_CODE);
               }
           });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //If the result is from paypal
        if (requestCode == MyGlobal.PAYPAL_REQUEST_CODE) {

            //If the result is OK i.e. user has not canceled the payment
            if (resultCode == Activity.RESULT_OK) {
                //Getting the payment confirmation
                PaymentConfirmation confirm = data.getParcelableExtra(PaymentActivity.EXTRA_RESULT_CONFIRMATION);

                //if confirmation is not null
                if (confirm != null) {
                    try {
                        //Getting the payment details
                        String paymentDetails = confirm.toJSONObject().toString(4);
                        Log.i("paymentExample", paymentDetails);

                        //Starting a new activity for the payment details and also putting the payment details with intent
                        startActivity(new Intent(this, ConfirmationActivity.class)
                                .putExtra("PaymentDetails", paymentDetails)
                                .putExtra("PaymentAmount", MyGlobal.fee));

                    } catch (JSONException e) {
                        Log.e("paymentExample", "an extremely unlikely failure occurred: ", e);
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.i("paymentExample", "The user canceled.");
            } else if (resultCode == PaymentActivity.RESULT_EXTRAS_INVALID) {
                Log.i("paymentExample", "An invalid Payment or PayPalConfiguration was submitted. Please see the docs.");
            }
        }
    }

    @Override
    public void onDestroy()
    {
        stopService(new Intent(this, PayPalService.class));
        super.onDestroy();
    }
}
