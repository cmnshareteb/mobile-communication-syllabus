package com.example.harshadbhandwaldar.payment;

import com.paypal.android.sdk.payments.PayPalConfiguration;

import java.util.Random;

public class MyGlobal {
    public static String name;
    public static String psw;
    public static String user_name1;
    public static Boolean fee_payed=false;
    public static int fee=1000;
    public static int id=MyGlobal.genID();

    private static int genID() {
        Random r = new Random();
        int randomNumber = r.nextInt(10000-1)+9999;
        return randomNumber;
    }

    public static  String upi;
    public static String year_of_study;
    public static final String Paypal_ClientID = "Af-0ySlinOQK1a6PdZwFX0tv8lA5G96M7fUu3k74sz4Ghebl7X3vhXR9C7TbNoz7_UXChIu3ESCfoUlJ";

    //Pay pal intent request code to track onActivityResult method
    public static final int PAYPAL_REQUEST_CODE = 123;


    //Pay pal Configuration Object
    public static PayPalConfiguration config = new PayPalConfiguration()
            // Start with mock environment.  When ready, switch to sandbox (ENVIRONMENT_SANDBOX)
            // or live (ENVIRONMENT_PRODUCTION)
            .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
            .clientId(MyGlobal.Paypal_ClientID);

    public static void fees(String year_of_study)
    {
        switch (year_of_study)
        {
            case "FE":
                MyGlobal.fee=1000;
                break;
            case "SE":
                MyGlobal.fee=1500;
                break;
            case "TE":
                MyGlobal.fee=2000;
                break;
        }
    }
}
