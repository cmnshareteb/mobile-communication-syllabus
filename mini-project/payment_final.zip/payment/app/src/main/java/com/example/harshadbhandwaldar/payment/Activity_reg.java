package com.example.harshadbhandwaldar.payment;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.icu.text.SimpleDateFormat;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.ParseException;
import java.util.Date;

public class Activity_reg extends AppCompatActivity {
    Button reg;
    EditText name2;
    EditText pass;
    EditText pass1;
    EditText user_name;
    RadioGroup rdgrp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        reg=(Button) findViewById(R.id.btn_r);
        name2=(EditText) findViewById(R.id.etNameR);
        pass=(EditText) findViewById(R.id.etpass);
        pass1=(EditText) findViewById(R.id.etpass1);
        user_name=(EditText) findViewById(R.id.etusername);
        rdgrp = (RadioGroup) findViewById(R.id.rbgrp);
        rdgrp.clearCheck();

        rdgrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) rdgrp.findViewById(checkedId);
                if(rb !=null)
                {
                    MyGlobal.year_of_study=rb.getText().toString();
                    MyGlobal.fees(MyGlobal.year_of_study);
                    Toast.makeText(Activity_reg.this, rb.getText(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    reg.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String p1=pass.getText().toString();
            String p2=pass1.getText().toString();
            if(p1.equals(p2)) {
                MyGlobal.name = name2.getText().toString();
                MyGlobal.psw = p1;
                MyGlobal.user_name1 = user_name.getText().toString();

                Toast.makeText(Activity_reg.this, "Register Successful!", Toast.LENGTH_SHORT).show();

                Intent i2 = new Intent(Activity_reg.this, MainActivity.class);
                startActivity(i2);
                finish();
            }
            else
            {
                Toast.makeText(Activity_reg.this, "Registration failed! check password again!", Toast.LENGTH_SHORT).show();
            }
        }
    });

    }
}
