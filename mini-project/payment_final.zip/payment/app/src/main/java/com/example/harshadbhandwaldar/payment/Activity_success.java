package com.example.harshadbhandwaldar.payment;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;

public class Activity_success extends AppCompatActivity {

    Button exit;
    TextView msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        msg= (TextView) findViewById(R.id.tvsuccess);
        exit=(Button) findViewById(R.id.btn_exit);

        String m = "Name:"+MyGlobal.name+"\nFees:"+String.valueOf(MyGlobal.fee)+"\nPayment ID:"+String.valueOf(MyGlobal.id)+"\nPAYMENT SUCCESSFUL!!";
        msg.setText(m);


        String filename = "myfile";
        FileOutputStream outputStream;

        try
        {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(m.getBytes());
            outputStream.close();
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        Toast.makeText(this, "The reciept is stored on device privately.", Toast.LENGTH_SHORT).show();


            exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
